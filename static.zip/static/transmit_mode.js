document.addEventListener("DOMContentLoaded", async () => {
    const select = document.getElementById("deviceSelect");

    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoDevices = devices.filter(d => d.kind === "videoinput");

    videoDevices.forEach((device, index) => {
        const option = document.createElement("option");
        option.value = device.deviceId;
        option.text = device.label || `Камера ${index + 1}`;
        select.appendChild(option);
    });
});

document.getElementById("add-camera-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = e.target.camera_name.value;
    const deviceId = document.getElementById("deviceSelect").value;

    const res = await fetch("/api/add_camera", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, device_id: deviceId })
    });

    if (res.ok) {
        e.target.reset();
        location.reload();
    } else {
        alert("Ошибка при добавлении камеры");
    }
});
