const socket = io();
const img = document.getElementById('resultImage');

socket.on('processed_frame', data => {
    console.log("Получен кадр:", data.slice(0, 30)); // покажем первые 30 символов
    if (data && data.startsWith('data:image')) {
        img.src = data;
    } else {
        console.warn("Получено нечто странное:", data);
    }
});