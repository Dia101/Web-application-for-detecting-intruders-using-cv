const socket = io();
const video = document.getElementById('localVideo');
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');

// Храни выбранный deviceId
let selectedDeviceId = null;
async function startVideo() {
     const devices = await navigator.mediaDevices.enumerateDevices();
     const videoDevices = devices.filter(device => device.kind === "videoinput");

    selectedDeviceId = videoDevices.find(d => d.deviceId === DEVICE_ID)?.deviceId;

    if (!selectedDeviceId) {
        alert("Камера с указанным deviceId не найдена.");
        return;
    }

  const stream = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: { exact: selectedDeviceId } }
    });

    video.srcObject = stream;
    video.play();

   video.onloadedmetadata = () => {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    setInterval(() => {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataURL = canvas.toDataURL('image/jpeg');
        socket.emit('frame',{image: dataURL,camera_id: CAMERA_ID});
    }, 600);
};}

startVideo();
